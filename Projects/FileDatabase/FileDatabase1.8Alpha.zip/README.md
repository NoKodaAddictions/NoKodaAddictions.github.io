Welcome to File Database 1.7.2 Alpha. Just like 1.7.1, there can be multiple databases.
But this time, you can back up your data to GitHub! Just insert a GitHub Repository and
it will push the data! Have any issues? DM me on Discord or on Issues!


@ThatCodeAddict#7289
https://github.com/ThePythonAddict/File-Database/issues

Reqirements:
Python 3.5+

GitPython

`pip install gitpython`


Visit The Official Website!
https://sites.google.com/view/filedatabase/home